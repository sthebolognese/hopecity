const Sequelize = require('sequelize');
const connection = require('./database');
const Usuario = require('./Usuario');

const Relatorio = connection.define('usuario', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true, 
        primaryKey: true,
        allowNull: false 
    }
    // recrutadorId: { 
    //     type: Sequelize.INTEGER,
    //     references: {
    //       model: Recrutador,  
    //       key: 'id', 
    //     },
    //     allowNull: false,
    //   },
    //   vagasId: { 
    //     type: Sequelize.INTEGER,
    //     references: {
    //       model: Vagas,  
    //       key: 'id', 
    //     },
    //     allowNull: false,
    //   },
    //   usuarioId: { 
    //     type: Sequelize.INTEGER,
    //     references: {
    //       model: Usuario,  
    //       key: 'id', 
    //     },
    //     allowNull: false,
    //   },
});

Relatorio.sync({force: false}).then(() => {console.log("tabela criada")})
module.exports = Relatorio;
