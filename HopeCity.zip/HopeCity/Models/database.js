const sequelize = require('sequelize')
const connection = new sequelize('HopeCity','root','escola',{
    host: 'localhost',
    dialect: 'mysql',
    logging: false
});

module.exports = connection