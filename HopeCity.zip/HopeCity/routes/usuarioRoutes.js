const express = require("express")
const { cadastroUsuario } = require("../controllers/usuarioControllers")

const route = express.Router()

route.post("/cadastroUsuario", cadastroUsuario)

module.exports = route;