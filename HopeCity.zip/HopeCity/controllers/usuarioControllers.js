const bcrypt = require("bcrypt")
const Usuario = require("../Models/Usuario");
const { where } = require("sequelize");

const cadastroUsuario = (req, res) =>{
    const {nome, email, senha} = req.body;

    if(!nome || !email || !senha ){
        return res.status(404).json({error: "todos os campos são obrigatórios"})
    }

    
    
    Usuario.findOne({where: {email}})
        .then((usuarioExistente) =>{
            if(usuarioExistente){
                throw{status:400, message:" Email ja cadastrado"}
            }
            return bcrypt.hash(String(senha), 10)
        })
        .then((senhaHash) =>{
            return Usuario.creat({nome, email, senha:senhaHash});
        })
        .then((novoUsuario) => {
            res.status(201).json({message: "Usuario cadastrado com sucesso", usuario: novoUsuario})
        })
        .catch((error) => {
            if(error.status){
                return res.status(error.status).json({error:error.message})
            }
            console.log("Erro ao cadastrar usuario: ", error)
            res.status(500).json({error: "Erro interno do servidor"})
        })
}
module.exports={cadastroUsuario}